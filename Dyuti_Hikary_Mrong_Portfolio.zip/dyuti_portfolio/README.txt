DYUTI HIKARY MRONG — PORTFOLIO

1. Open index.html in a browser.
2. Your supplied profile image is already included in images/profile.png.
3. Put your CV in assets/ and name it CV.pdf.
4. Edit text in index.html if needed.
5. Deploy the folder using GitHub Pages when ready.
